package com.example.backend_transport.service;

import com.example.backend_transport.model.Bus;
import com.example.backend_transport.repository.BusRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class BusService {

    private final BusRepository busRepository;

    public BusService(BusRepository busRepository) {
        this.busRepository = busRepository;
    }

    public List<Bus> getAllBuses() {
        return busRepository.findAll();
    }

    public Bus saveBus(Bus bus) {
        return busRepository.save(bus);
    }
    public Optional<Bus> getBusWithTrajets(int idBus) {
        return busRepository.findById(idBus);
    }

    public Bus findById(Long id) {
       
        throw new UnsupportedOperationException("Unimplemented method 'findById'");
    }
}