package com.example.backend_transport.model;


import java.util.Date;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;

import jakarta.persistence.ManyToOne;

@Entity
public class Statistiques {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int idStatistique;

    private Date periode;
    private String ligne;
    private int nombreTrajets;

    @ManyToOne
    @JoinColumn(name = "id_bus")  // Référence à l'id_bus dans la table bus
    private Bus bus;

    // Getters et Setters
    public int getIdStatistique() {
        return idStatistique;
    }

    public void setIdStatistique(int idStatistique) {
        this.idStatistique = idStatistique;
    }

    public Date getPeriode() {
        return periode;
    }

    public void setPeriode(Date periode) {
        this.periode = periode;
    }

    public String getLigne() {
        return ligne;
    }

    public void setLigne(String ligne) {
        this.ligne = ligne;
    }

    public int getNombreTrajets() {
        return nombreTrajets;
    }

    public void setNombreTrajets(int nombreTrajets) {
        this.nombreTrajets = nombreTrajets;
    }

    public Bus getBus() {
        return bus;
    }

    public void setBus(Bus bus) {
        this.bus = bus;
    }
}