package com.example.backend_transport.service;

import com.example.backend_transport.model.Trajet;
import com.example.backend_transport.repository.TrajetRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TrajetService {

    private final TrajetRepository trajetRepository;

    public TrajetService(TrajetRepository trajetRepository) {
        this.trajetRepository = trajetRepository;
    }

    // Récupérer tous les trajets
    public List<Trajet> getAllTrajets() {
        return trajetRepository.findAll();
    }

    // Récupérer un trajet par ID
    public Optional<Trajet> getTrajetById(int id) {
        return trajetRepository.findById(id);
    }

    // Ajouter un nouveau trajet
    public Trajet createTrajet(Trajet trajet) {
        return trajetRepository.save(trajet);
    }

    // Mettre à jour un trajet existant
    public Optional<Trajet> updateTrajet(int id, Trajet trajetDetails) {
        return trajetRepository.findById(id).map(trajet -> {
            trajet.setDepart(trajetDetails.getDepart());
            trajet.setArrivee(trajetDetails.getArrivee());
            trajet.setTempsEstime(trajetDetails.getTempsEstime());
            return trajetRepository.save(trajet);
        });
    }

    public boolean deleteTrajet(int id) {
        Optional<Trajet> trajet = trajetRepository.findById(id);
        if (trajet.isPresent()) {
            trajetRepository.delete(trajet.get());
            return true;
        }
        return false;
    }
    
}
