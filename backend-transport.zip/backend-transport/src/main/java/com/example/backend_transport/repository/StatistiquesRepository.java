package com.example.backend_transport.repository;

import com.example.backend_transport.model.Statistiques;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StatistiquesRepository extends JpaRepository<Statistiques, Integer> {
}