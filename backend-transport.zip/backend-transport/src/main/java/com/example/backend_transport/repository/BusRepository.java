package com.example.backend_transport.repository;

import com.example.backend_transport.model.Bus;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BusRepository extends JpaRepository<Bus, Integer> {
}