package com.example.backend_transport;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendTransportApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendTransportApplication.class, args);
	}

}
