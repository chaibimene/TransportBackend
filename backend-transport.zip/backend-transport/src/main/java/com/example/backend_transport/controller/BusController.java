package com.example.backend_transport.controller;

import com.example.backend_transport.model.Bus;
import com.example.backend_transport.repository.BusRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.example.backend_transport.service.BusService;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/api/transport")
public class BusController {

    @Autowired
    private BusRepository busRepository;
    @Autowired
    private BusService busService;

    // Créer un bus
    @PostMapping("/buses")
    public ResponseEntity<Bus> createBus(@RequestBody Bus bus) {
        try {
            Bus savedBus = busRepository.save(bus);
            return new ResponseEntity<>(savedBus, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // Récupérer un bus par ID
    @GetMapping("/buses/{id}")
    public ResponseEntity<Bus> getBusById(@PathVariable("id") Integer id) {
        Optional<Bus> bus = busRepository.findById(id);
        return bus.map(value -> new ResponseEntity<>(value, HttpStatus.OK))
                  .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    // Supprimer un bus par ID
    @DeleteMapping("/buses/{id}")
    public ResponseEntity<HttpStatus> deleteBus(@PathVariable("id") Integer id) {
        try {
            busRepository.deleteById(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // Récupérer tous les buses
    @GetMapping("/buses")
    public List<Bus> getAllBuses() {
        return busRepository.findAll();
    }
    @PutMapping("/buses/{id}")
    public ResponseEntity<Bus> updateBus(@PathVariable int id, @RequestBody Bus updatedBus) {
        Optional<Bus> existingBus = busRepository.findById(id);
    
        if (existingBus.isPresent()) {
            Bus bus = existingBus.get();
            bus.setLigne(updatedBus.getLigne());
            bus.setLocalisation(updatedBus.getLocalisation());
            bus.setEtat(updatedBus.getEtat());
            busRepository.save(bus);
            return ResponseEntity.ok(bus);
        } else {
            return ResponseEntity.notFound().build();
        }
    }
    

     // Gestionnaire d'exceptions pour un bus non trouvé
    @ExceptionHandler(NoSuchElementException.class)
    public ResponseEntity<String> handleBusNotFound(NoSuchElementException e) {
        return new ResponseEntity<>("Bus not found", HttpStatus.NOT_FOUND);
    }

    // Gestionnaire d'exceptions pour toute autre erreur
    @ExceptionHandler(Exception.class)
    public ResponseEntity<String> handleGenericError(Exception e) {
        return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
    }
    @GetMapping("/buses/{idBus}/trajets")
    public Optional<Bus> getBusWithTrajets(@PathVariable int idBus) {
        return busService.getBusWithTrajets(idBus);
    }
}