package com.example.backend_transport.service;

import com.example.backend_transport.model.Station;
import com.example.backend_transport.repository.StationRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class StationService {

    private final StationRepository stationRepository;

    public StationService(StationRepository stationRepository) {
        this.stationRepository = stationRepository;
    }

    // Obtenir toutes les stations
    public List<Station> getAllStations() {
        return stationRepository.findAll();
    }

    // Obtenir une station par ID
    public Optional<Station> getStationById(int id) {
        return stationRepository.findById(id);
    }

    // Créer une nouvelle station
    public Station createStation(Station station) {
        return stationRepository.save(station);
    }

    // Mettre à jour une station existante
    public Optional<Station> updateStation(int id, Station stationDetails) {
        return stationRepository.findById(id).map(station -> {
            station.setNomStation(stationDetails.getNomStation());
            station.setLocalisation(stationDetails.getLocalisation());
            return stationRepository.save(station);
        });
    }

    // Supprimer une station
    public boolean deleteStation(int id) {
        return stationRepository.findById(id).map(station -> {
            stationRepository.delete(station);
            return true;
        }).orElse(false);
    }
}