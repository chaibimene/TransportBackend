package com.example.backend_transport.service;

import com.example.backend_transport.model.Statistiques;
import com.example.backend_transport.repository.StatistiquesRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StatistiquesService {

    @Autowired
    private StatistiquesRepository statistiquesRepository;

    public List<Statistiques> getAllStatistiques() {
        return statistiquesRepository.findAll();
    }

    public Statistiques getStatistiquesById(int id) {
        return statistiquesRepository.findById(id).orElse(null);
    }

    public Statistiques saveStatistiques(Statistiques statistiques) {
        return statistiquesRepository.save(statistiques);
    }

    public void deleteStatistiques(int id) {
        statistiquesRepository.deleteById(id);
    }
}