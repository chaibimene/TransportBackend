package com.example.backend_transport.repository;

import com.example.backend_transport.model.Station;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StationRepository extends JpaRepository<Station, Integer> {
}