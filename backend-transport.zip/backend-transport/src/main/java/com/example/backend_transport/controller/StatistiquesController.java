package com.example.backend_transport.controller;

import com.example.backend_transport.model.Statistiques;
import com.example.backend_transport.repository.StatistiquesRepository;
import com.example.backend_transport.service.StatistiquesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/statistiques")
public class StatistiquesController {

    @Autowired
    private StatistiquesService statistiquesService;
     @Autowired
    private StatistiquesRepository statistiquesRepository;

    @GetMapping
    public List<Statistiques> getAllStatistiques() {
        return statistiquesService.getAllStatistiques();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Statistiques> getStatistiquesById(@PathVariable int id) {
        Statistiques statistiques = statistiquesService.getStatistiquesById(id);
        return statistiques != null ? ResponseEntity.ok(statistiques) : ResponseEntity.notFound().build();
    }

    @PostMapping
    public Statistiques createStatistiques(@RequestBody Statistiques statistiques) {
        return statistiquesService.saveStatistiques(statistiques);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteStatistiques(@PathVariable int id) {
        statistiquesService.deleteStatistiques(id);
        return ResponseEntity.noContent().build();
    }
    @PutMapping("/{id}")
public ResponseEntity<Statistiques> updateStatistique(@PathVariable int id, @RequestBody Statistiques updatedStatistique) {
    Optional<Statistiques> existingStatistique = statistiquesRepository.findById(id);

    if (existingStatistique.isPresent()) {
        Statistiques statistique = existingStatistique.get();
        statistique.setPeriode(updatedStatistique.getPeriode());
        statistique.setLigne(updatedStatistique.getLigne());
        statistique.setNombreTrajets(updatedStatistique.getNombreTrajets());
        statistiquesRepository.save(statistique);
        return ResponseEntity.ok(statistique);
    } else {
        return ResponseEntity.notFound().build();
    }
}

}