package com.example.backend_transport.controller;

import com.example.backend_transport.model.Station;
import com.example.backend_transport.model.Trajet;
import com.example.backend_transport.repository.StationRepository;
import com.example.backend_transport.repository.TrajetRepository;
import com.example.backend_transport.service.TrajetService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;


import java.util.List;

@RestController
@RequestMapping("/api/trajets")
public class TrajetController {

    private final TrajetService trajetService;
    private final StationRepository stationRepository;
    private final TrajetRepository trajetRepository;
  

    @Autowired
    public TrajetController(TrajetService trajetService, StationRepository stationRepository, TrajetRepository trajetRepository) {
        this.trajetService = trajetService;
        this.stationRepository = stationRepository;
        this.trajetRepository = trajetRepository;  
    }

    // GET: Récupérer tous les trajets
    @GetMapping
    public ResponseEntity<List<Trajet>> getAllTrajets() {
        List<Trajet> trajets = trajetService.getAllTrajets();
        return ResponseEntity.ok(trajets);
    }

    // GET: Récupérer un trajet par ID
    @GetMapping("/{id}")
    public ResponseEntity<Trajet> getTrajetById(@PathVariable int id) {
        return trajetService.getTrajetById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // POST: Créer un trajet
    @PostMapping
    public ResponseEntity<Trajet> createTrajet(@Validated @RequestBody Trajet trajet) {
        try {
            Station depart = stationRepository.findById(trajet.getDepart().getIdStation())
                    .orElseThrow(() -> new RuntimeException("Station de départ non trouvée"));

            Station arrivee = stationRepository.findById(trajet.getArrivee().getIdStation())
                    .orElseThrow(() -> new RuntimeException("Station d'arrivée non trouvée"));

            trajet.setDepart(depart);
            trajet.setArrivee(arrivee);

            Trajet savedTrajet = trajetService.createTrajet(trajet);
            return ResponseEntity.status(HttpStatus.CREATED).body(savedTrajet);

        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(null);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<Trajet> updateTrajet(@PathVariable int id, @RequestBody Trajet trajetDetails) {
        try {
            // Rechercher le trajet existant
            Trajet existingTrajet = trajetRepository.findById(id)
                    .orElseThrow(() -> new RuntimeException("Trajet non trouvé"));
    
            // Rechercher les stations à partir des IDs
            Station depart = stationRepository.findById(trajetDetails.getDepart().getIdStation())
                    .orElseThrow(() -> new RuntimeException("Station de départ non trouvée"));
            Station arrivee = stationRepository.findById(trajetDetails.getArrivee().getIdStation())
                    .orElseThrow(() -> new RuntimeException("Station d'arrivée non trouvée"));
    
            // Mettre à jour les données du trajet
            existingTrajet.setDepart(depart);
            existingTrajet.setArrivee(arrivee);
            existingTrajet.setTempsEstime(trajetDetails.getTempsEstime());
    
            // Sauvegarder dans la base
            Trajet updatedTrajet = trajetRepository.save(existingTrajet);
    
            return ResponseEntity.ok(updatedTrajet);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(null);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteTrajet(@PathVariable int id) {
        try {
            System.out.println("Tentative de suppression du trajet avec l'ID: " + id); // Log pour vérifier l'ID reçu
            boolean deleted = trajetService.deleteTrajet(id);
            return deleted ? ResponseEntity.noContent().build() : ResponseEntity.notFound().build();
        } catch (RuntimeException e) {
            System.err.println("Erreur lors de la suppression: " + e.getMessage()); // Log de l'erreur
            return ResponseEntity.badRequest().build();
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
    
    
}
