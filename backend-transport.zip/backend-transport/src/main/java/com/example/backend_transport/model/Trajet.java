package com.example.backend_transport.model;



import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;

import java.util.List;

@Entity
public class Trajet {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int idTrajet;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "depart")  // Référence à l'id_station de départ
    private Station depart;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "arrivee")  // Référence à l'id_station d'arrivée
    private Station arrivee;

    private int tempsEstime;

    @ManyToMany(mappedBy = "trajets")  // La relation inversée Many-to-Many avec Bus
    private List<Bus> buses;

    // Getters et Setters
    public int getIdTrajet() {
        return idTrajet;
    }

    public void setIdTrajet(int idTrajet) {
        this.idTrajet = idTrajet;
    }

    public Station getDepart() {
        return depart;
    }

    public void setDepart(Station depart) {
        this.depart = depart;
    }

    public Station getArrivee() {
        return arrivee;
    }

    public void setArrivee(Station arrivee) {
        this.arrivee = arrivee;
    }

    public int getTempsEstime() {
        return tempsEstime;
    }

    public void setTempsEstime(int tempsEstime) {
        this.tempsEstime = tempsEstime;
    }

    public List<Bus> getBuses() {
        return buses;
    }

    public void setBuses(List<Bus> buses) {
        this.buses = buses;
    }
}